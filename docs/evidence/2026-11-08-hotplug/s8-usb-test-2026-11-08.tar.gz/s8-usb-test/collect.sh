#!/bin/sh
# S8 USB hotplug observation harness (READ-ONLY).
# Production disk /dev/sdb1 is never mounted, unmounted or written.
# Does not modify /etc/config/samba, the adapter, or restart the service.
#
# usage:
#   sh collect.sh run [seconds]   # foreground; MAX defaults to 14400s
#   sh collect.sh stop
#   sh collect.sh status
#   sh collect.sh summary
#
# background start:
#   nohup sh /userdisk/data/s8-usb-test/collect.sh run >/dev/null 2>&1 &
#
# output:
#   /userdisk/data/s8-usb-test/collect.log   1 sample/s (change= field)
#   /userdisk/data/s8-usb-test/meta.txt      start/stop/baseline
#   /userdisk/data/s8-usb-test/snap/*         snapshots on every change

BASE=${USB_TEST_BASE:-/userdisk/data/s8-usb-test}
ROOT=${USB_TEST_ROOT:-/userdisk/data/s7root}
UCI=${USB_TEST_UCI:-/etc/config/samba}
CONF=$ROOT/current/etc/smb.conf
INTERVAL=${USB_TEST_INTERVAL:-1}
MAX=${USB_TEST_MAX:-14400}
LOGTICK=${USB_TEST_LOGTICK:-5}
LOG=$BASE/collect.log
PIDF=$BASE/collect.pid
STOP=$BASE/STOP
SNAP=$BASE/snap
META=$BASE/meta.txt

mkdir -p "$SNAP" || exit 1

md5of() { md5sum "$@" 2>/dev/null | awk '{print $1}'; }
parts_sig() { md5sum /proc/partitions 2>/dev/null | awk '{print $1}'; }
sysblock() { ls /sys/block 2>/dev/null | sort | tr '\n' ','; }
extmounts() { awk '$2 ~ /^\/extdisks\// {print $1, $2, $3}' /proc/mounts 2>/dev/null | sort; }
ext_sig() { extmounts | md5sum | awk '{print $1}'; }
sections() { grep '^\[' "$CONF" 2>/dev/null | tr -d '[]' | tr '\n' ','; }
sec_sig() { sections | md5sum | awk '{print $1}'; }
nsec() { c=$(grep -c '^\[' "$CONF" 2>/dev/null); echo "${c:-0}"; }
usbnames() { awk -F'[][]' '/^\[XiaoMi-usb[0-9]+\]/{printf "%s,", $2}' "$CONF" 2>/dev/null; }
usbblocks() { awk '/^\[XiaoMi-usb[0-9]+\]/{p=1} p{print} p && /^[ \t]*$/{p=0}' "$CONF" 2>/dev/null; }
usb_sig() { usbblocks | md5sum | awk '{print $1}'; }
uci_sig() { md5sum "$UCI" 2>/dev/null | awk '{print $1}'; }
uci_mtime() { stat -c '%Y' "$UCI" 2>/dev/null || echo na; }
listeners() { netstat -ltnp 2>/dev/null | grep -E ':(139|445)[[:space:]]' | awk '{print $NF}' | sort -u | tr '\n' ','; }
hotlog() {
    { logread 2>/dev/null
      tail -n 60 /tmp/messages 2>/dev/null
      tail -n 40 /userdisk/data/s8compat/logs/hotplug.log 2>/dev/null
      dmesg 2>/dev/null | tail -n 80
      tail -n 20 /var/log/log.smbd 2>/dev/null
    } | grep -Ei 'usb|scsi|hotplug|shareupdate|samba|extdisk|tntfs|block|/dev/sd' | tail -n 40
}
log_sig() { hotlog | md5sum | awk '{print $1}'; }

snap() { # tag epoch
    f=$SNAP/$1-$2.txt
    case $1 in
    partitions) cp /proc/partitions "$f" 2>/dev/null ;;
    sysblock) ls /sys/block >"$f" 2>/dev/null ;;
    mounts) extmounts >"$f" ;;
    smbconf) cp "$CONF" "$f" 2>/dev/null ;;
    usb) usbblocks >"$f" ;;
    uci) cp "$UCI" "$f" 2>/dev/null ;;
    logread) hotlog >"$f" ;;
    esac
}

cmd_run() {
    if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null; then
        echo "already running pid=$(cat "$PIDF")"
        return 1
    fi
    [ -n "$1" ] && MAX=$1
    rm -f "$STOP"
    echo $$ >"$PIDF"
    {
        echo "== start local=$(date '+%Y-%m-%dT%H:%M:%S%z') epoch=$(date +%s) tz=$(date +%Z) offset=$(date +%z)"
        echo "== host=$(cat /proc/sys/kernel/hostname 2>/dev/null) kernel=$(uname -r) current=$(readlink "$ROOT/current" 2>/dev/null)"
        echo "== conf=$CONF uci=$UCI interval=${INTERVAL}s max=${MAX}s log_sample=${LOGTICK}s"
        echo "== baseline extmounts:"
        extmounts
        echo "== baseline sections: $(sections)"
        echo "== baseline uci=$(uci_sig) mtime=$(uci_mtime) listeners=$(listeners)"
    } >>"$META"
    cp /proc/mounts "$SNAP/mounts-full-start.txt" 2>/dev/null
    cp /etc/TZ "$SNAP/TZ.txt" 2>/dev/null
    pp= psb= pe= psc= pu= puc= pl= plg=
    n=0
    start=$(date +%s)
    while [ ! -f "$STOP" ]; do
        now=$(date +%s)
        if [ $((now - start)) -ge "$MAX" ]; then
            echo "== max runtime ${MAX}s reached epoch=$now" >>"$META"
            break
        fi
        ts=$(date '+%Y-%m-%dT%H:%M:%S%z')
        pa=$(parts_sig); sb=$(sysblock); ex=$(ext_sig)
        sc=$(sec_sig); ub=$(usb_sig); uc=$(uci_sig); um=$(uci_mtime)
        li=$(listeners); ns=$(nsec); un=$(usbnames)
        lg=-
        if [ $((n % LOGTICK)) -eq 0 ]; then lg=$(log_sig); fi
        ch=
        [ "$pa" != "$pp" ] && ch="$ch parts"
        [ "$sb" != "$psb" ] && ch="$ch sysblock"
        [ "$ex" != "$pe" ] && ch="$ch mounts"
        [ "$sc" != "$psc" ] && ch="$ch sections"
        [ "$ub" != "$pu" ] && ch="$ch usb"
        [ "$uc" != "$puc" ] && ch="$ch uci"
        [ "$li" != "$pl" ] && ch="$ch listeners"
        if [ "$lg" != "-" ] && [ "$lg" != "$plg" ]; then ch="$ch logread"; fi
        sch=$ch
        ch=${ch# }
        [ -z "$ch" ] && ch=none
        [ "$n" -eq 0 ] && ch=baseline
        echo "$ts epoch=$now parts=$pa sysblock=$sb mounts=$ex sections=$sc nsec=$ns usbnames=$un usb=$ub uci=$uc uci_mtime=$um listeners=$li log=$lg change=$ch" >>"$LOG"
        case "$sch" in *parts*) snap partitions "$now"; snap sysblock "$now" ;; esac
        case "$sch" in *mounts*) snap mounts "$now" ;; esac
        case "$sch" in *sections* | *usb*) snap smbconf "$now"; snap usb "$now" ;; esac
        case "$sch" in *uci*) snap uci "$now" ;; esac
        case "$sch" in *logread*) snap logread "$now" ;; esac
        pp=$pa; psb=$sb; pe=$ex; psc=$sc; pu=$ub; puc=$uc; pl=$li
        [ "$lg" != "-" ] && plg=$lg
        n=$((n + 1))
        sleep "$INTERVAL"
    done
    echo "== stop local=$(date '+%Y-%m-%dT%H:%M:%S%z') epoch=$(date +%s) samples=$n" >>"$META"
    rm -f "$PIDF"
}

cmd_stop() {
    touch "$STOP"
    if [ -f "$PIDF" ]; then kill "$(cat "$PIDF")" 2>/dev/null; fi
    echo stopped
}

cmd_status() {
    if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null; then
        echo "running pid=$(cat "$PIDF") samples=$(wc -l <"$LOG" 2>/dev/null)"
        ps -o pid,ppid,etime,args 2>/dev/null | grep '[c]ollect.sh' || true
    else
        echo stopped
    fi
    tail -n 3 "$LOG" 2>/dev/null
}

cmd_summary() {
    echo "== meta =="
    tail -n 20 "$META" 2>/dev/null
    echo "== transitions (epoch delta change) =="
    awk '
    {
        e=""; ch=""
        for (i = 1; i <= NF; i++) {
            if ($i ~ /^epoch=/) { split($i, a, "="); e = a[2] }
            if ($i ~ /^change=/) { split($i, b, "="); ch = b[2] }
        }
        if (ch != "" && ch != "none") {
            if (prev != "") printf "%s +%ss %s\n", $1, e - prev, ch
            else printf "%s %s\n", $1, ch
            prev = e
        }
    }' "$LOG"
    echo "== snapshots =="
    ls -l "$SNAP" 2>/dev/null
    echo "== last sample =="
    tail -n 1 "$LOG" 2>/dev/null
}

case "${1:-run}" in
run) cmd_run "$2" ;;
stop) cmd_stop ;;
status) cmd_status ;;
summary) cmd_summary ;;
*) echo "usage: $0 {run [seconds]|stop|status|summary}"; exit 2 ;;
esac
